package data;

public interface MessageProcessor {
    Message process(Message msg);
}
